from setuptools import setup, find_packages

setup(
      name="fdttest",
      version="1.00",
      description="FDTtest",
      author="FDT",
      url="http://www.fdt.com.tw",
      license="LGPL",
      packages= find_packages(),
      scripts=["scripts/fdttest"],
      )
